# ======================= BOOTNASKO OS 1.2 =======================
# Made by Ananasko (AkiPaki54)
# Safe calculator, AI mode, colors, web
# Terminal-style OS simulation

import os
import shutil
import webbrowser
import re
import time
try:
    import msvcrt
except ImportError:
    msvcrt = None

# ======================= COLOR SUPPORT ==========================

try:
    from colorama import Fore, Style, init
    init(autoreset=False)
    color_enabled = True
except:
    color_enabled = False

current_color = ""

_original_print = print

def print(*args, **kwargs):
    # Keep the selected color active for all future output.
    if color_enabled and current_color:
        _original_print(current_color, end="")
        _original_print(*args, **kwargs)
    else:
        _original_print(*args, **kwargs)

def set_color(c):
    global current_color

    if not color_enabled:
        _original_print("Color support unavailable. Install 'colorama'.")
        return

    table = {
        "red": Fore.RED,
        "green": Fore.GREEN,
        "yellow": Fore.YELLOW,
        "blue": Fore.BLUE,
        "white": Fore.WHITE
    }

    if c in table:
        current_color = table[c]
        # Apply the new color to this line and everything after it.
        _original_print(current_color + f"Color set to {c}.")
    else:
        _original_print("Unknown color. Options: red, green, yellow, blue, white")

# ======================= FAKE HACK ==============================

def cmd_fakehack():
    """
    Realistic-looking hacking animation.
    This is only a visual simulation: it does not connect to networks,
    scan real machines, steal data, or execute hacking commands.
    Press any key to stop.
    """
    if msvcrt is None:
        print("FAKE HACK requires a Windows console.")
        return

    print("╔══════════════════════════════════════════════════════════════╗")
    print("║                 BOOTNASKO SECURITY CONSOLE                 ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print("Simulation mode: ACTIVE")
    print("Press any key to stop.")
    print()

    targets = [
        "10.24.18.7", "10.24.18.12", "172.16.0.24",
        "192.168.1.14", "192.168.1.22"
    ]
    services = ["SSH", "HTTP", "HTTPS", "SMB", "RDP"]
    stages = [
        "Resolving host",
        "Enumerating services",
        "Checking response",
        "Analyzing headers",
        "Verifying access",
        "Generating session",
        "Closing simulation"
    ]

    import random

    cycle = 0
    progress = 0

    while True:
        if msvcrt.kbhit():
            msvcrt.getwch()
            break

        target = targets[cycle % len(targets)]
        service = services[cycle % len(services)]
        stage = stages[cycle % len(stages)]

        if cycle % 7 == 0:
            print(f"[{time.strftime('%H:%M:%S')}] TARGET   {target}")
        elif cycle % 7 == 1:
            print(f"[{time.strftime('%H:%M:%S')}] SERVICE  {service:<5} port={random.choice([22, 80, 443, 445, 3389])}")
        elif cycle % 7 == 2:
            progress = (progress + random.randint(8, 19)) % 100
            print(f"[{time.strftime('%H:%M:%S')}] SCAN     {stage:<22} [{progress:3d}%]")
        elif cycle % 7 == 3:
            latency = random.randint(8, 96)
            print(f"[{time.strftime('%H:%M:%S')}] RESPONSE latency={latency}ms status=200")
        elif cycle % 7 == 4:
            token = "".join(random.choice("0123456789ABCDEF") for _ in range(12))
            print(f"[{time.strftime('%H:%M:%S')}] SESSION  id={token}")
        elif cycle % 7 == 5:
            print(f"[{time.strftime('%H:%M:%S')}] MODULE   sandbox_payload.bin loaded (simulation)")
        else:
            print(f"[{time.strftime('%H:%M:%S')}] STATUS   simulated operation complete")

        cycle += 1
        time.sleep(0.055)

    print()
    print("Simulation stopped.")
    print(f"Lines generated: {cycle}")

# ======================= SAFE CALCULATOR ========================

def cmd_calc(expr):
    if not re.fullmatch(r"[0-9+-*/().\s]+", expr):
        print("Error: Invalid characters.")
        return
    try:
        result = eval(expr, {"__builtins__": None}, {})
        print(result)
    except:
        print("Math error.")

# ======================= COMMAND FUNCTIONS ======================

def cmd_help():
    for cmd, desc in commands.items():
        print(f"{cmd:<10} - {desc}")

def cmd_mkfile(name):
    open(name, "w").close()
    print("File created:", name)

def cmd_write(name):
    if not os.path.exists(name):
        print("File not found.")
        return
    text = input("Write: ")
    with open(name, "w") as f:
        f.write(text)
    print("Written.")

def cmd_read(name):
    if not os.path.exists(name):
        print("File not found.")
        return
    with open(name) as f:
        print(f.read())

def cmd_append(name):
    text = input("Append: ")
    with open(name, "a") as f:
        f.write(text)
    print("Appended.")

def cmd_rename(old, new):
    if not os.path.exists(old):
        print("File not found.")
        return
    os.rename(old, new)
    print("Renamed.")

def cmd_del(name):
    if os.path.isdir(name):
        shutil.rmtree(name)
    else:
        os.remove(name)
    print("Deleted:", name)

def cmd_ls():
    print("\n".join(os.listdir(".")))

def cmd_mkdir(name):
    try:
        os.mkdir(name)
        print("Folder created.")
    except:
        print("Error making folder.")

def cmd_cd(name):
    try:
        os.chdir(name)
        print("Now in:", os.getcwd())
    except:
        print("Folder not found.")

def cmd_pwd(): print(os.getcwd())

def cmd_clear(): os.system("cls" if os.name == "nt" else "clear")

def cmd_copy(src, dst):
    try:
        shutil.copy(src, dst)
        print("Copied.")
    except:
        print("Copy error.")

def cmd_move(src, dst):
    try:
        shutil.move(src, dst)
        print("Moved.")
    except:
        print("Move error.")

def cmd_info():
    print("Bootnasko OS")
    print("Directory:", os.getcwd())

def cmd_echo(text): print(text)

def cmd_exit():
    print("Exiting Bootnasko...")
    exit()

def cmd_touch(name):
    with open(name, "a"): pass
    print("Touched:", name)

def cmd_tree():
    for root, dirs, files in os.walk(".", topdown=True):
        level = root.count(os.sep)
        indent = " " * 2 * level
        print(f"{indent}{os.path.basename(root)}/")
        subindent = " " * 2 * (level + 1)
        for f in files:
            print(f"{subindent}{f}")

def cmd_ver(): print("Bootnasko v1.2")

def cmd_type(name): cmd_read(name)

def cmd_newfile(name):
    text = input("Content: ")
    with open(name, "w") as f:
        f.write(text)
    print("File created with content.")

def cmd_empty(name):
    open(name, "w").close()
    print("File emptied.")

def cmd_exists(name):
    print("Exists." if os.path.exists(name) else "Does not exist.")

def cmd_web(url):
    if not url.startswith("http://") and not url.startswith("https://"):
        print("Invalid URL. Must start with http:// or https://")
        return
    print("Opening:", url)
    webbrowser.open(url)

def cmd_about(): print("Bootnasko OS made by Ananasko.")
def cmd_sys(): print("System folder: /systemstuff")
def cmd_boot(): print("Reboot? No :) just text.")
def cmd_why(): print("Because Bootnasko.")
def cmd_hi(): print("Hello from Bootnasko!")
def cmd_ping(): print("Pong!")
def cmd_cls(): cmd_clear()
def cmd_commands(): cmd_help()

# ======================= COMMAND LIST ===========================

commands = {
    "help":      "show all commands",
    "mkfile":    "create file",
    "write":     "write to file",
    "read":      "read file",
    "append":    "append text",
    "rename":    "rename file",
    "delete":    "delete file/folder",
    "list":      "list directory",
    "mkdir":     "make folder",
    "cd":        "change directory",
    "pwd":       "show current folder",
    "copy":      "copy file",
    "move":      "move file",
    "touch":     "create empty file",
    "empty":     "empty file",
    "newfile":   "create file with content",
    "type":      "same as read",
    "exists":    "check if file exists",
    "tree":      "folder tree",
    "about":     "info page",
    "sys":       "system root",
    "boot":      "reboot text",
    "why":       "funny phrase",
    "hi":        "say hi",
    "ping":      "pong!",
    "ver":       "show version",
    "info":      "system info",
    "echo":      "print text",
    "clear":     "clear screen",
    "cls":       "same as clear",
    "exit":      "shuts down Bootnasko OS",
    "calc":      "safe calculator",
    "web":       "open website",
    "colors":    "change text color",
    "fakehack":  "fake hacking simulation"
}

# ======================= MAIN LOOP ===============================

print("Bootnasko OS booting... OK")  # ALWAYS WHITE

while True:
    cmd_input = input("ABN:_ ").split()

    if not cmd_input: 
        continue

    cmd = cmd_input[0]
    args = cmd_input[1:]

    if cmd not in commands:
        print("Unknown command.")
        continue

    if cmd == "help": cmd_help()
    elif cmd == "mkfile" and args: cmd_mkfile(args[0])
    elif cmd == "write" and args: cmd_write(args[0])
    elif cmd == "read" and args: cmd_read(args[0])
    elif cmd == "append" and args: cmd_append(args[0])
    elif cmd == "rename" and len(args) == 2: cmd_rename(args[0], args[1])
    elif cmd == "delete" and args: cmd_del(args[0])
    elif cmd == "list": cmd_ls()
    elif cmd == "mkdir" and args: cmd_mkdir(args[0])
    elif cmd == "cd" and args: cmd_cd(args[0])
    elif cmd == "pwd": cmd_pwd()
    elif cmd == "copy" and len(args) == 2: cmd_copy(args[0], args[1])
    elif cmd == "move" and len(args) == 2: cmd_move(args[0], args[1])
    elif cmd == "touch" and args: cmd_touch(args[0])
    elif cmd == "tree": cmd_tree()
    elif cmd == "ver": cmd_ver()
    elif cmd == "type" and args: cmd_type(args[0])
    elif cmd == "newfile" and args: cmd_newfile(args[0])
    elif cmd == "empty" and args: cmd_empty(args[0])
    elif cmd == "exists" and args: cmd_exists(args[0])
    elif cmd == "info": cmd_info()
    elif cmd == "echo" and args: cmd_echo(" ".join(args))
    elif cmd == "clear": cmd_clear()
    elif cmd == "cls": cmd_cls()
    elif cmd == "exit": cmd_exit()
    elif cmd == "calc" and args: cmd_calc(" ".join(args))
    elif cmd == "web" and args: cmd_web(args[0])
    elif cmd == "colors" and args: set_color(args[0].lower())
    elif cmd == "fakehack": cmd_fakehack()
    elif cmd == "about": cmd_about()
    elif cmd == "sys": cmd_sys()
    elif cmd == "boot": cmd_boot()
    elif cmd == "why": cmd_why()
    elif cmd == "hi": cmd_hi()
    elif cmd == "ping": cmd_ping()
    else:
        print("Invalid usage.")
